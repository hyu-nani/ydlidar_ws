/*
 * calculate.h
 *
 * Created: 2022-03-16 ���� 9:26:56
 *  Author: cube_
 */ 
void positionCalculate(double nowPosL, double nowPosR){
	double distanceL = diameter*M_PI/pulse*(nowPosL-oldPosL);
	double distanceR = diameter*M_PI/pulse*(nowPosR-oldPosR);
	oldPosL = nowPosL;
	oldPosR = nowPosR;
	//�̵����� ���
	double c = (distanceL-distanceR)/2;
	//double angle = asin(2*sin(c/robot_wheel_pitch)*cos(c/robot_wheel_pitch))*(PI/180);
	double angle = 2*asin(c/robot_wheel_pitch)*(180.0/M_PI);

	//x, y ���
	robotX += -sin(((angle/2+robot_angle))*(M_PI/180.0))*(distanceL+distanceR)/2;
	robotY += cos(((angle/2+robot_angle))*(M_PI/180.0))*(distanceL+distanceR)/2;
	
	robot_angle += angle;
	if(robot_angle > 180)
		robot_angle = robot_angle - 360;
	else if(robot_angle < -180)
		robot_angle = robot_angle + 360;
}